<?php
header( 'Location: byname.php' );
?>
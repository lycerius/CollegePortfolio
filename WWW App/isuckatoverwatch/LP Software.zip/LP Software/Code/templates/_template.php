<!--
Use this file as a skeleton for all webpages on this domain
-->
<?php
include_once("templates/template.php");
createHeader(NULL); #Include your javascript file as the param
?>
<!--
  ===Page content goes here===
-->
<?php endPage(); ?>
